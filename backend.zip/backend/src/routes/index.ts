import type { FastifyPluginAsync } from "fastify";
import { adminRoutes } from "./admin.routes.js";
import { authRoutes } from "./auth.routes.js";
import { customerRoutes } from "./customer.routes.js";
import { productRoutes } from "./product.routes.js";
import { serviceRequestRoutes } from "./service-request.routes.js";
import { supportRoutes } from "./support.routes.js";
import { warrantyRegistrationRoutes } from "./warranty-registration.routes.js";
import { warrantyRoutes } from "./warranty.routes.js";
import { publicInquiryRoutes, adminInquiryRoutes } from "./inquiry.routes.js";

/** Registers every API group under the /api prefix (set in app.ts). */
export const apiRoutes: FastifyPluginAsync = async (app) => {
  await app.register(authRoutes, { prefix: "/auth" });
  await app.register(customerRoutes, { prefix: "/customers" });
  await app.register(productRoutes, { prefix: "/products" });
  await app.register(warrantyRoutes, { prefix: "/warranties" });
  await app.register(adminRoutes, { prefix: "/admin" });
  await app.register(adminInquiryRoutes, { prefix: "/admin" });
  await app.register(publicInquiryRoutes, { prefix: "/inquiries" });
  await app.register(supportRoutes, { prefix: "/support" });
  await app.register(serviceRequestRoutes, { prefix: "/service-requests" });
  await app.register(warrantyRegistrationRoutes, { prefix: "/warranty-registrations" });
};
