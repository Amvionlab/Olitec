/** MOCK DATA — Phase 1 only. Sample records served by the mock repositories; nothing is ever written here. */
import type { Customer, Product, SupportRequest, Warranty } from "../types.js";

export const products: Product[] = [
  { id: "prd_101", slug: "aquapure-ro-plus", name: "AquaPure RO+ Water Purifier", model: "AP-RO-750", category: "Water Purifier", warrantyMonths: 12, priceInr: 15990, description: "7-stage RO + UV + UF purification with mineral balance." },
  { id: "prd_102", slug: "powermax-1100-inverter", name: "PowerMax 1100 Sine Wave Inverter", model: "PM-1100-SW", category: "Inverter", warrantyMonths: 24, priceInr: 7490, description: "Pure sine wave home inverter for fans, lights and TV." },
  { id: "prd_103", slug: "tubular-150ah-battery", name: "LongLife 150Ah Tall Tubular Battery", model: "LL-TT-150", category: "Battery", warrantyMonths: 60, priceInr: 14250, description: "Tall tubular inverter battery for long power cuts." },
  { id: "prd_104", slug: "breezecool-55l-desert-cooler", name: "BreezeCool 55L Desert Air Cooler", model: "BC-DC-55", category: "Air Cooler", warrantyMonths: 12, priceInr: 10990, description: "Large-room cooler with honeycomb pads and auto swing." },
  { id: "prd_105", slug: "aerosilent-bldc-fan", name: "AeroSilent BLDC Ceiling Fan", model: "AS-BLDC-1200", category: "Ceiling Fan", warrantyMonths: 36, priceInr: 3990, description: "Energy-efficient 28 W BLDC fan with remote." },
  { id: "prd_106", slug: "chefpro-750w-mixer-grinder", name: "ChefPro 750W Mixer Grinder", model: "CP-MG-750", category: "Kitchen Appliance", warrantyMonths: 24, priceInr: 4290, description: "750 W motor with three stainless steel jars." },
];
export const serialNumbers = [
  {
    serialNumber: "APRO750TEST001",
    productId: 101,
  },
  {
    serialNumber: "PM1100TEST001",
    productId: 102,
  },
  {
    serialNumber: "LLTT150TEST001",
    productId: 103,
  },
  {
    serialNumber: "BCDC55TEST001",
    productId: 104,
  },
  {
    serialNumber: "ASBLDCTEST001",
    productId: 105,
  },
  {
    serialNumber: "CPMG750TEST001",
    productId: 106,
  },
];
export const customers: Customer[] = [
  { id: "cus_2041", name: "Priya Sharma", email: "priya.sharma@example.com", mobile: "9876543210", city: "Bengaluru", state: "Karnataka", status: "Active", createdAt: "2023-04-18T10:00:00+05:30" },
  { id: "cus_2042", name: "Arjun Mehta", email: "arjun.mehta@example.com", mobile: "9845012345", city: "Pune", state: "Maharashtra", status: "Active", createdAt: "2024-01-09T14:20:00+05:30" },
  { id: "cus_2043", name: "Kavya Reddy", email: "kavya.reddy@example.com", mobile: "9900112233", city: "Hyderabad", state: "Telangana", status: "Active", createdAt: "2024-06-22T09:45:00+05:30" },
  { id: "cus_2044", name: "Rahul Verma", email: "rahul.verma@example.com", mobile: "8123456789", city: "Chennai", state: "Tamil Nadu", status: "Inactive", createdAt: "2022-11-30T17:05:00+05:30" },
  { id: "cus_2045", name: "Sneha Iyer", email: "sneha.iyer@example.com", mobile: "7899001122", city: "Kochi", state: "Kerala", status: "Active", createdAt: "2025-08-14T11:30:00+05:30" },
];

export const warranties: Warranty[] = [
  { id: "war_5001", warrantyNumber: "WR-2025-004812", customerId: "cus_2041", productId: "prd_101", serialNumber: "AP750K24110387", purchaseDate: "2025-11-02", invoiceNumber: "INV/BLR/2025/18842", dealerName: "Sri Lakshmi Electronics", startDate: "2025-11-02", endDate: "2026-11-01", status: "Active", adminRemark: null, submittedAt: "2025-11-04T10:22:00+05:30", history: [{ at: "2025-11-04T10:22:00+05:30", action: "Registration submitted", by: "Priya Sharma" }, { at: "2025-11-05T12:00:00+05:30", action: "Approved", by: "Anita Rao" }] },
  { id: "war_5002", warrantyNumber: "WR-2025-003107", customerId: "cus_2041", productId: "prd_102", serialNumber: "PM11SW2507A0912", purchaseDate: "2025-07-14", invoiceNumber: "INV/BLR/2025/11206", dealerName: "PowerZone Batteries", startDate: "2025-07-14", endDate: "2027-07-13", status: "Active", adminRemark: null, submittedAt: "2025-07-15T18:05:00+05:30", history: [{ at: "2025-07-15T18:05:00+05:30", action: "Registration submitted", by: "Priya Sharma" }, { at: "2025-07-16T11:10:00+05:30", action: "Approved", by: "Mohan Das" }] },
  { id: "war_5004", warrantyNumber: "WR-2026-007731", customerId: "cus_2041", productId: "prd_105", serialNumber: "ASB1200261009XQ", purchaseDate: "2026-10-19", invoiceNumber: "AMZ-406-7781234-552", dealerName: "Online purchase", startDate: null, endDate: null, status: "Pending", adminRemark: null, submittedAt: "2026-10-21T09:41:00+05:30", history: [{ at: "2026-10-21T09:41:00+05:30", action: "Registration submitted", by: "Priya Sharma" }] },
  { id: "war_5005", warrantyNumber: "WR-2024-001455", customerId: "cus_2041", productId: "prd_104", serialNumber: "BCDC55240318772", purchaseDate: "2024-03-30", invoiceNumber: "INV/BLR/2024/03317", dealerName: "Cool Home Appliances", startDate: "2024-03-30", endDate: "2025-03-29", status: "Expired", adminRemark: null, submittedAt: "2024-04-01T12:15:00+05:30", history: [{ at: "2024-04-01T12:15:00+05:30", action: "Registration submitted", by: "Priya Sharma" }, { at: "2024-04-02T10:00:00+05:30", action: "Approved", by: "Anita Rao" }, { at: "2025-03-30T00:00:00+05:30", action: "Expired automatically", by: "System" }] },
  { id: "war_5006", warrantyNumber: "WR-2026-006920", customerId: "cus_2041", productId: "prd_106", serialNumber: "CPMG75026B", purchaseDate: "2026-08-27", invoiceNumber: "INV-88123", dealerName: "Local kitchen store", startDate: null, endDate: null, status: "Rejected", adminRemark: "The serial number on the invoice does not match the serial number entered.", submittedAt: "2026-08-28T20:30:00+05:30", history: [{ at: "2026-08-28T20:30:00+05:30", action: "Registration submitted", by: "Priya Sharma" }, { at: "2026-08-30T15:45:00+05:30", action: "Rejected", by: "Mohan Das", remark: "The serial number on the invoice does not match the serial number entered." }] },
  { id: "war_5010", warrantyNumber: "WR-2026-007802", customerId: "cus_2042", productId: "prd_103", serialNumber: "LLTT150261012345", purchaseDate: "2026-10-12", invoiceNumber: "INV/PNQ/2026/55102", dealerName: "Vijay Sales", startDate: null, endDate: null, status: "Pending", adminRemark: null, submittedAt: "2026-10-14T16:12:00+05:30", history: [{ at: "2026-10-14T16:12:00+05:30", action: "Registration submitted", by: "Arjun Mehta" }] },
  { id: "war_5011", warrantyNumber: "WR-2025-002210", customerId: "cus_2043", productId: "prd_101", serialNumber: "AP750K25020111", purchaseDate: "2025-02-11", invoiceNumber: "INV/HYD/2025/07781", dealerName: "Reliance Digital", startDate: "2025-02-11", endDate: "2026-02-10", status: "Expired", adminRemark: null, submittedAt: "2025-02-12T13:00:00+05:30", history: [{ at: "2025-02-12T13:00:00+05:30", action: "Registration submitted", by: "Kavya Reddy" }, { at: "2025-02-13T10:30:00+05:30", action: "Approved", by: "Anita Rao" }] },
  { id: "war_5012", warrantyNumber: "WR-2026-005540", customerId: "cus_2045", productId: "prd_102", serialNumber: "PM11SW2606B4410", purchaseDate: "2026-06-03", invoiceNumber: "INV/COK/2026/22019", dealerName: "Home Needs Store", startDate: "2026-06-03", endDate: "2028-06-02", status: "Active", adminRemark: null, submittedAt: "2026-06-04T09:15:00+05:30", history: [{ at: "2026-06-04T09:15:00+05:30", action: "Registration submitted", by: "Sneha Iyer" }, { at: "2026-06-05T11:40:00+05:30", action: "Approved", by: "Mohan Das" }] },
];

export const supportRequests: SupportRequest[] = [
  { id: "sup_301", ticketNumber: "SR-2026-01287", customerId: "cus_2041", warrantyId: "war_5001", category: "Repair", subject: "Purifier making noise after filter change", message: "The pump makes a loud humming sound since the last filter service.", status: "In Progress", createdAt: "2026-10-16T11:02:00+05:30", updatedAt: "2026-10-18T15:40:00+05:30" },
  { id: "sup_302", ticketNumber: "SR-2026-01344", customerId: "cus_2041", warrantyId: "war_5004", category: "Installation", subject: "Installation for new BLDC fan", message: "Please schedule installation for the AeroSilent fan in the master bedroom.", status: "Open", createdAt: "2026-10-21T09:55:00+05:30", updatedAt: "2026-10-21T09:55:00+05:30" },
  { id: "sup_303", ticketNumber: "SR-2026-00412", customerId: "cus_2041", warrantyId: "war_5002", category: "Warranty Claim", subject: "Inverter beeping during power cut", message: "Inverter beeps continuously and shuts down after 20 minutes of backup.", status: "Resolved", createdAt: "2026-04-05T19:20:00+05:30", updatedAt: "2026-04-08T13:10:00+05:30" },
];
